// App.jsx
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function App() {
  return (
    <main className="p-4 grid gap-4 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-center">AI Video Editing Tools</h1>

      {/* Thumbnail Generator */}
      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold">Video Thumbnail Generator</h2>
          <input type="file" accept="image/*" className="mt-2" />
          <Button className="mt-2">Generate Thumbnail</Button>
        </CardContent>
      </Card>

      {/* Facebook Caption Generator */}
      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold">Facebook Caption Creator</h2>
          <input type="text" placeholder="Enter video topic" className="w-full p-2 border mt-2" />
          <Button className="mt-2">Generate Facebook Caption</Button>
        </CardContent>
      </Card>

      {/* YouTube Caption Generator */}
      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-semibold">YouTube Caption Generator</h2>
          <input type="text" placeholder="Enter video topic" className="w-full p-2 border mt-2" />
          <Button className="mt-2">Generate YouTube Caption</Button>
        </CardContent>
      </Card>
    </main>
  );
}